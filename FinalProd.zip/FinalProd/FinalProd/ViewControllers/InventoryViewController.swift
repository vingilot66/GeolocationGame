//
//  InventoryViewController.swift
//  FinalProd
//
//  Created by Andrew Mckie on 2019-12-08.
//  Copyright © 2019 Steven Winstanley. All rights reserved.
//
// Inventory screen, which displays all items a user has within a tableview
import UIKit

class InventoryViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    let mainDelegate = UIApplication.shared.delegate as! AppDelegate
    
    //Set items
    var items : Array<Item> = []
    
    //Sets number of rows in table, required for tableviews
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mainDelegate.UserData.Items!.count
    }
    
    //Sets table cell from InventoryCell.swift, inputs data into each cell from inventory
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableInCell : InventoryCell = tableView.dequeueReusableCell(withIdentifier: "cell") as? InventoryCell ?? InventoryCell(style:UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        
        let rowNum = indexPath.row
        tableInCell.primaryLabel.text = String(items[rowNum].Name)
        tableInCell.secondaryLabel.text = String(items[rowNum].Characteristic)
        tableInCell.thirdLabel.text = String(items[rowNum].ItemType)
        tableInCell.backgroundColor = .brown
        return tableInCell
    }
    
    //Sets tableview cell hight
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    //Enable items from UserData to be referenced in code
    override func viewDidLoad() {
        super.viewDidLoad()
        
        items = mainDelegate.UserData.Items!
        
        
         
    }
    
}
