//
//  CharViewController.swift
//  FinalProd
//
//  Created by Christopher Reynolds on 2019-12-07.
//  Copyright © 2019 Steven Winstanley. All rights reserved.
//
//This class is used as the view controller for the main screen on the party view, it allows the user to change the members within their active party

import UIKit

class CharViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var mainDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet var table : UITableView!
    
    //Fires when page is loaded, fills up images and names of all current party members into their respective boxes
    override func viewDidLoad() {
        super.viewDidLoad()
        if(mainDelegate.UserData.Party!.count > 3){
            imgFour.image = UIImage(named: mainDelegate.UserData.Party![3].ViewPic)
            lblFour.text = mainDelegate.UserData.Party![3].Name
        }
        if(mainDelegate.UserData.Party!.count > 2){
            imgThree.image = UIImage(named: mainDelegate.UserData.Party![2].ViewPic)
            lblThree.text = mainDelegate.UserData.Party![2].Name
        }
        if(mainDelegate.UserData.Party!.count > 1){
            imgTwo.image = UIImage(named: mainDelegate.UserData.Party![1].ViewPic)
            lblTwo.text = mainDelegate.UserData.Party![1].Name
        }
        if(mainDelegate.UserData.Party!.count > 0){
            imgOne.image = UIImage(named: mainDelegate.UserData.Party![0].ViewPic)
            lblOne.text = mainDelegate.UserData.Party![0].Name
        }
    }
    
    //Decrare all label and images
    @IBOutlet var lblOne : UILabel!
    @IBOutlet var lblTwo : UILabel!
    @IBOutlet var lblThree : UILabel!
    @IBOutlet var lblFour : UILabel!
    
    @IBOutlet var imgOne : UIImageView!
    @IBOutlet var imgTwo : UIImageView!
    @IBOutlet var imgThree : UIImageView!
    @IBOutlet var imgFour : UIImageView!
    
    //Sets number of rows in character tableview, required for tableview
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        mainDelegate.UserData.Heroes!.count
    }
    
    //Sets height of each cell, required for tableview
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    //Sets up tableview with the cell class, CharCell. Sets content of all cells
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableCharCell : CharCell = tableView.dequeueReusableCell(withIdentifier: "cell") as? CharCell ?? CharCell(style:UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        let rowNum = indexPath.row
        let name = mainDelegate.UserData.Heroes![rowNum].Name
        let imgName = UIImage(named:mainDelegate.UserData.Heroes![rowNum].ViewPic)
        
        tableCharCell.primaryLabel.text = name
        tableCharCell.myImageView.image = imgName
        tableCharCell.backgroundColor = .brown
        tableCharCell.accessoryType = .disclosureIndicator
        
        return tableCharCell
    }
    
    //Cycles images and names when a new character is selected to be put in party
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        lblFour.text = lblThree.text
        lblThree.text = lblTwo.text
        lblTwo.text = lblOne.text
        imgFour.image = imgThree.image
        imgThree.image = imgTwo.image
        imgTwo.image = imgOne.image
        lblOne.text = mainDelegate.UserData.Heroes![indexPath.row].Name
        imgOne.image = UIImage(named: mainDelegate.UserData.Heroes![indexPath.row].ViewPic)!
        //Removes first character if their are over 4 characters in the party
            if mainDelegate.UserData.Party!.count == 4 {
            mainDelegate.UserData.Heroes!.append(mainDelegate.UserData.Party!.first!)
            mainDelegate.UserData.Party!.removeFirst()
            mainDelegate.UserData.Party!.append(mainDelegate.UserData.Heroes![indexPath.row])
        } else {
            mainDelegate.UserData.Party!.append(mainDelegate.UserData.Heroes![indexPath.row])
        }
        mainDelegate.UserData.Heroes!.remove(at: indexPath.row)
        //Save UserData to local storage
        mainDelegate.UserData.LocalSave()
        tableView.reloadData()
    }
    
    
    //Unwind segue
    @IBAction func unwindToCharViewController(segue: UIStoryboardSegue)
    {
        
    }

}
