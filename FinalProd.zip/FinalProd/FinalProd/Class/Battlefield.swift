//
//  Battlefield.swift
//  FinalProd
//
//  Created by Alex Teodorescu on 2019-12-07.
//  Copyright © 2019 Steven Winstanley. All rights reserved.
//
// Creates array of both enemies and heroes that are going to be used within our battlescene

import UIKit

//used for combat to store data
class Battlefield: NSObject {
    
    var Enemies : [Enemy] = []
    var Heroes : [Hero] = []

}
