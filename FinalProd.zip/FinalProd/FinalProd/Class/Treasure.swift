//
//  Treasure.swift
//  FinalProd
//
//  Created by Alex Teodorescu on 2019-11-08.
//  Copyright © 2019 Steven Winstanley. All rights reserved.
//
// Gives character items after successful combat

import Foundation

//not used
class Treasure {
    
    public var Items : [Item] = [];
}
