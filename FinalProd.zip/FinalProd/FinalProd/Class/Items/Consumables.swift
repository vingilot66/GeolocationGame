//
//  Consumables.swift
//  FinalProd
//
//  Created by Andrew Mckie on 2019-11-08.
//  Copyright © 2019 Steven Winstanley. All rights reserved.
//

import UIKit
//Parent class for consumables
class Consumables: Item {
    //define on use
    func onUse(User : Hero) -> Void {} 
}
