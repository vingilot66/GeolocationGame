//
//  PartyViewController.swift
//  FinalProd
//
//  Created by Steven Winstanley on 2019-12-08.
//  Copyright © 2019 Steven Winstanley. All rights reserved.
//

import WatchKit

class PartyViewController: NSObject {
    @IBOutlet var img: WKInterfaceImage!
    @IBOutlet var label: WKInterfaceLabel!
    
}
